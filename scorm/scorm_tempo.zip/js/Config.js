Config.endpoint = "";
Config.authUser = "";
Config.authPassword = "";
Config.actor = { "mbox":[""], "name":[""] };
Config.registration = "";